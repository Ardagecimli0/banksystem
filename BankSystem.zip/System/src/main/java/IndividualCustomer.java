
public class IndividualCustomer extends Customer{

    private String gender;
    private String identificationInfo;
    private String occupation;

    public IndividualCustomer(String name, String address, String contactNumber, String gender, String identificationInfo, String occupation) {
        super(name, address,contactNumber);
        this.gender = gender;
        this.identificationInfo = identificationInfo;
        this.occupation = occupation;
    }

    @Override

    public String toString() {
        return super.toString() + ", Gender: " + gender + ", ID: " + identificationInfo + ", Occupation: " + occupation;
    }

    @Override
    public void createAccount() {
    }

    @Override
    public void printAccountDetails() {
        super.toString();
    }

  

 
}
