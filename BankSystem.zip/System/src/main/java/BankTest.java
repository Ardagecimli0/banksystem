
public class BankTest {

    public static void main(String[] args) {

        // Create the first individual customer
        IndividualCustomer customer1 = new IndividualCustomer("Arda", "Maltepe", "0544 693 2759", "Male", "0544 693 2759", "Site Owner");

        // Create the first portfolio
        FinancialPortfolio portfolio1 = new FinancialPortfolio();

        // Create accounts for the first customer
        CheckingAccount checkingAccount = new CheckingAccount(1, 1000, customer1, true, true, true);
        SavingsAccount savingsAccount1 = new SavingsAccount(2, 1500, customer1, 2.5);
        SavingsAccount savingsAccount2 = new SavingsAccount(3, 2000, customer1, 3.0);
        
        // Adding accounts to portfolio
        portfolio1.addAccount(savingsAccount1);
        portfolio1.addAccount(savingsAccount2);

        // Create transactions for depositing money
        Transaction deposit1 = new Transaction(500, "deposit");
        Transaction deposit2 = new Transaction(700, "deposit");
        Transaction deposit3 = new Transaction(1000, "deposit");

        // Deposit money to accounts via transactions
        savingsAccount1.deposit(deposit1.getAmount());
        savingsAccount2.deposit(deposit2.getAmount());
        checkingAccount.deposit(deposit3.getAmount());

        // Display account details for each account created
        System.out.println("Account details for the first portfolio:");
        System.out.println(portfolio1);

        // Display total value of the first portfolio
        System.out.println("Total value of the first portfolio: " + portfolio1.totalValue());

        // Remove the second savings account from the portfolio
        portfolio1.removeAccount(savingsAccount2);
        System.out.println("After removing an account:");
        System.out.println("Total value of the first portfolio: " + portfolio1.totalValue());

        // Print all account information in the portfolio
        System.out.println("All account details in the first portfolio:");
        System.out.println(portfolio1);

        // Create the second individual customer
        IndividualCustomer customer2 = new IndividualCustomer("Cem", "Bostancı", "0544 752 8274", "Male", "371 68 10 8644", "E-Liquid Brand Owner");

        // Create the second portfolio
        FinancialPortfolio portfolio2 = new FinancialPortfolio();

        // Create a checking account for the second customer
        CheckingAccount checkingAccount2 = new CheckingAccount(4, 2000, customer2, true, true, true);

        // Display account details for the checking account created
        System.out.println("Account details for the second portfolio:");
        System.out.println(checkingAccount2);

        // Add the checking account to the second portfolio
        portfolio2.addAccount(checkingAccount2);

        // Display total value of the second portfolio
        System.out.println("Total value of the second portfolio: " + portfolio2.totalValue());

        // Print all account information in the second portfolio
        System.out.println("All account details in the second portfolio:");
        System.out.println(portfolio2);

        // Compare the first and the second portfolios
        System.out.println("Comparison of the first and the second portfolios:");
        System.out.println("Portfolio 1: " + portfolio1);
        System.out.println("Portfolio 2: " + portfolio2);

        // Create a transaction for some money to be deposited
        Transaction deposit4 = new Transaction(1500, "deposit");

        // Have the second customer deposit money to his checking account via the transaction created
        checkingAccount2.deposit(deposit4.getAmount());

        // Create a transaction for some money to be transferred
        Transaction transfer = new Transaction(500, "transfer");

        // Have the first customer transfer some amount from his checking account to the second customer’s checking account via the transaction created
         checkingAccount.transfer(checkingAccount, checkingAccount2, 100);
        

        // Display account details for each account created
        System.out.println("Account details after transactions:");
        System.out.println("Account details for the first portfolio:");
        System.out.println(portfolio1);
        System.out.println("Account details for the second portfolio:");
        System.out.println(portfolio2);

        // Compare the first and the second portfolios again
        System.out.println("Comparison of the first and the second portfolios after transactions:");
        System.out.println("Portfolio 1: " + portfolio1);
        System.out.println("Portfolio 2: " + portfolio2);


    }
}
