
public interface AccountManagement {
    
    
    public void createAccount();
    public void printAccountDetails();
    public void updateContactNumber(String newContactDetails);
    
    
}
