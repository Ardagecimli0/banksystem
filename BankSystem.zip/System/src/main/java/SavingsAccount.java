
public class SavingsAccount extends Account {

    private double interestRate;
    private String status; // Active, Closed
    private long iban;

    public SavingsAccount(int accountNumber, double balance, Customer owner, double interestRate) {
        super(accountNumber, balance, owner);
        System.out.println("Account NUMBER: " + accountNumber);
        this.interestRate = interestRate;
        this.status = "Active";
        long Randomİban = (long) (Math.random() * 1000000000) + 100000000;
        this.iban = Randomİban;
        System.out.println("Your IBAN Adress: " + iban);
    }

    @Override
    public double futureBalance(int years) {
        return balance * Math.pow(1 + interestRate / 100, years);
    }

    @Override
    public String toString() {
        return super.toString() + "Future Balance (1 year): " + futureBalance(1) + ", Status: " + status;
    }

    @Override
    public void deposit(Account account, double amount) {
    }

    @Override
    public void withdraw(Account account, double amount) {

    }

    @Override
    public void transfer(Account fromAccount, Account toAccount, double amount) {
        
    }

    public void printAccountDetails() {
        System.out.println("Your Saving Account Details \n"
                + "Interest Rate: " + interestRate + "\n"
                + "Stauts: " + status + "\n"
                + "IBAN Adress");
    }
}
