
public class InstitutionalCustomer extends Customer {

    private String Institution;
    private String Sector;
    private double Revenue;

    public InstitutionalCustomer(String name, String address, String contactNumber, String Institution, String Sector, double Revenue) {
        super(name, address, contactNumber);
       this.Institution = Institution;
        this.Sector = Sector;
        this.Revenue = Revenue;
    }

    @Override
    public String toString() {
        return super.toString() + ", Type: " + Institution + ", Sector: " + Sector + ", Revenue: $" + Revenue;
    }

    @Override
    public void createAccount() {
     
    }

    @Override
    public void printAccountDetails() {
       super.toString();
    }
}
