import java.util.ArrayList;
import java.util.Date;

public class Transaction {
    private static int transactionCounter = 0;
    private int transactionId;
    private double amount;
    private Date date;  // Transaction Date
    private String type; // "deposit" or "withdrawal"

    public Transaction(double amount, String type) {
        this.transactionId = transactionCounter++;
        this.amount = amount;
        this.date = new Date(); // Current date
        this.type = type;
    }

    // Getters and toString
    public double getAmount() {
        return amount;
    }

    public String getType() {
        return type;
    }

    public Date getDate() {
        return date;
    }

    @Override
    public String toString() {
        return "Transaction ID: " + transactionId + ", Amount: " + amount + ", Date: " + date + ", Type: " + type;
    }
}