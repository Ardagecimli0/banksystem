
import java.util.ArrayList;
import java.util.*;


abstract class Account implements TransactionExecution {

    protected  int accountNumber;
    protected double balance;
    protected Customer owner;
    protected Date AccountDate;
    
    protected ArrayList<Transaction> transactionHistory = new ArrayList<>();

    public Account(int accountNumber, double balance, Customer owner) {
        this.accountNumber = accountNumber;
        this.balance = balance;
        this.owner = owner;
        this.AccountDate = new Date();
        System.out.println("Your account is created. Account creation date: " + this.AccountDate);
    }

    // Methods for deposit and withdrawal
    public void deposit(double amount) {
        balance += amount;
        transactionHistory.add(new Transaction(amount, "deposit"));
    }

    public void withdraw(double amount) {
        if (balance >= amount) {
            balance -= amount;
            transactionHistory.add(new Transaction(amount, "withdrawal"));
        } else {
            System.out.println("You do not have such amount of money");
        }
    }

    public abstract double futureBalance(int years);

    @Override
    public String toString() {
       
           return "Account Number: " + accountNumber + ", Balance: " + balance + "\n" + transactionHistory.toString();

        }
    }

  

