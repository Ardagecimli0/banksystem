
public class CheckingAccount extends Account {

    private static final double INTEREST_RATE = 3.0;
    private long iban;
    private boolean debitCard;
    private boolean atmAccess;
    private boolean onlineBankingAccess;

    public CheckingAccount(int accountNumber, double balance, Customer owner, boolean debitCard, boolean atmAccess, boolean onlineBankingAccess) {
        super(accountNumber, balance, owner);
        this.debitCard = debitCard;
        this.atmAccess = atmAccess;
        this.onlineBankingAccess = onlineBankingAccess;
        long Randomİban = (long) (Math.random() * 1000000000) + 100000000;
        this.iban = Randomİban;
        System.out.println("Your IBAN Adress: " + iban);
    }

    @Override
    public double futureBalance(int years) {
        return balance * Math.pow(1 + INTEREST_RATE / 100, years);
    }

    @Override
    public String toString() {
        return super.toString() + "Future Balance (1 year): " + futureBalance(1);
    }

    @Override
    public void deposit(Account account, double amount) {
    }

    @Override
    public void withdraw(Account account, double amount) {
    }

    @Override
    public void transfer(Account fromAccount, Account toAccount, double amount) {
    }

    public long getIban() {
        return iban;
    }

    public void setIban(long iban) {
        this.iban = iban;
    }

    public boolean isAtmAccess() {
        return atmAccess;
    }

    public void setAtmAccess(boolean atmAccess) {
        this.atmAccess = atmAccess;
    }

    public void printAccountDetails() {
        System.out.println("Your Checking Account Details \n"
                + "IBAN Adress:" + iban + "\n"
                + "Debit Card Status: " + debitCard + "\n"
                + "Atm Access Status: " + atmAccess + "\n"
                + "Online Banking Access: " + onlineBankingAccess + "\n"
                + "---------------------------------------------");
    }

}
