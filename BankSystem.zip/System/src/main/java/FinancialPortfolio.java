
import java.util.ArrayList;

public class FinancialPortfolio {

    private ArrayList<Account> accounts = new ArrayList<>();

    public void addAccount(Account account) {
        accounts.add(account);
    }

    public void removeAccount(Account account) {
        accounts.remove(account);
    }

    public double totalValue() {
        double total = 0;
        for (Account account : accounts) {
            total += account.balance;
        }
        return total;
    }

    @Override
    public String toString() {
        System.out.println("\"Portfolio Accounts:\n");
        for (Account account : accounts) {

            System.out.println(this.accounts);
        }
        return "*****";
    }

    public boolean equals(FinancialPortfolio otherPortfolio) {
        return this.totalValue() == otherPortfolio.totalValue();
    }
}
